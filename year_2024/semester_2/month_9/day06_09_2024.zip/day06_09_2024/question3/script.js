let condicao1 = true
let condicao2 = true
let condicao3 = true
let condicao4 = true
let condicao5 = true
let condicao6 = true
let condicao7 = true

if (condicao1 == true){
    if(condicao2 == true){
        if(condicao3 == true){
            console.log("1")
        } else{
            console.log("2")
        }
    } else {
        if(condicao4 == true){
            console.log("3")
        } else {
            console.log("4")
        }
    }
} else{
    if (condicao5 == true){
        if(condicao6 == true){
            console.log("5")
        } else {
            console.log("6")
        }
    } else {
        if(condicao7 == true){
            console.log("7")
        } else{
            console.log("8")
        }
    }
}